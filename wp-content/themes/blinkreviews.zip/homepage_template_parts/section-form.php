

<section class="section_form">

	
	<div class="form_wrapper">
		
		
		<?php gravity_form(1, false, true, false, '', true, 12); ?>
		
<!--
		<div class="success_wrapper">
			
			
			<img class="pink_success" src="<?php bloginfo('template_directory');?>/images/pink-success.svg"/>
			
			<span class="success_title">Success!</span>
			
			<span class="success_content">We have received your comments and will reach out to you shortly.</span>
			
			<span class="management_title">- Blink Lash Boutique Management</span>
			
			
		</div>
-->

		
	</div><!-- form_wrapper -->
	
	
</section><!-- section_form -->