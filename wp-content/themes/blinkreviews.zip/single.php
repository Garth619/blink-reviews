<?php get_header(); ?>

	

<?php get_template_part( 'loop', 'index' ); ?>

<?php // use get_template_part( 'loop', 'single' ) if needed ?>



<?php // get_sidebar(); ?>
<?php get_footer(); ?>
