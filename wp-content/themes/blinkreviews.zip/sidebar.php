


	<?php dynamic_sidebar( 'sidebar' ); ?>
			