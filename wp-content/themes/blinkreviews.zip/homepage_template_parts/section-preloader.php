<section class="preloader_wrapper">
	
	
	<img class="pre_logo" src="<?php bloginfo('template_directory');?>/images/pre-logo.svg"/>
	
	
</section><!-- prelodaer_wrapper -->