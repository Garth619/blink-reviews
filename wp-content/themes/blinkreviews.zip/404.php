<?php get_header(); ?>

	
				
<h1 class="entry-title">Not Found</h1>
				
				
<p>Apologies, but the page you requested could not be found.</p>
				
<?php // get_sidebar(); ?>
			
<?php get_footer(); ?>